# SECOHealth

The files contained in the ``master`` branch are automatically build from the sources contained in the ``sources`` branch. The build is done using [Genja](https://github.com/AlexandreDecan/Genja), a minimalist static website generator initially written specifically for SECOHealth.

Note: any modification manually performed on the ``master`` branch will eventually be reverted. Do **NOT** modify the ``master`` branch. Use the ``sources`` branch instead. 
